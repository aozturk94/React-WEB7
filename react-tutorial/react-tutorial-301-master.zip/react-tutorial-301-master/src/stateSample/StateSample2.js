import React, { useState } from 'react'

function StateSample2() {

    console.log('State Sample component rendered!');

    const [name, setName] = useState('Çağatay');

    const changeName = () => {
        setName('Wissen')
    }

    return (
        <div>
            <h1>{name}</h1>

            <button onClick={() => changeName()}>Change Name</button>
            
        </div>
    )
}

export default StateSample2
