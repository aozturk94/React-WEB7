import React, { useState } from 'react'


function StateSample3() {

    let metalBand = ['Iron Maiden', 'Rotting Christ', 'In Flames', 'Gojira', 'Moonspell', 'Parkway Drive'];

    const [metals, setMetals] = useState(metalBand);


    const deleteMetal = (name) => {

        let newMetalBands = metals.filter(q => q != name);
        setMetals(newMetalBands);
    }


    const deleteAll = () => {
        setMetals([])
    }

    return (
        <div>
            <button onClick={() => deleteAll()}>Delete All</button>
            <h1>Count: {metals.length}</h1>
            <ul>
                {
                    metals.map((item, key) => {

                      return (<>
                      <li>{item} - {key}</li>

                      <button onClick={() => deleteMetal(item)}>Delete 
                </button></>)

                    })
                }
            </ul>

        </div>
    )
}

export default StateSample3
