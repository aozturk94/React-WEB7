import React from 'react'
import { useNavigate } from 'react-router-dom'

function CategoryList(props) {

    let navigate = useNavigate();

    const goUpdatePage = (id) => {

        navigate('/kategoriler/guncelle/' + id)
    }

    return (
        <div>
            <table>
                <tr>
                    <td>Id</td>
                    <td>Name</td>
                    <td>Description</td>
                    <td>Delete</td>
                    <td>Update</td>

                </tr>
                {
                    props.categories && props.categories.map((item,key) => {
                      return  <tr>
                            <td>{item.id}</td>
                            <td>{item.name}</td>
                            <td>{item.description}</td>
                            <td><button onClick={() => props.deleteCategory(item.id)}>Delete</button></td>
                            <td><button onClick={() => goUpdatePage(item.id)}>Update</button></td>
                        </tr>
                    })
                }
            </table>
            
        </div>
    )
}

export default CategoryList


