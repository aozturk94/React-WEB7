import React, { useEffect, useState } from 'react'
import AddCategory from './AddCategory';
import CategoryList from './CategoryList';

function CategoryPage() {

    const [categories, setCategories] = useState([]);


    useEffect(() => {
        getCategories();
    }, []);


    const getCategories = () => {

        fetch("https://northwind.vercel.app/api/categories")
            .then(res => res.json())
            .then((data) => {
                setCategories(data);
            })
    }

    const deleteCategory = (id) => {
        let newCategories = categories.filter(q => q.id != id);
        setCategories(newCategories);
    }

    const addNewCategory = (item) => {

        // setCategoris([...categories,item]);

        let requestOptions = {
            method: 'POST',
            headers: {
                'Accept': 'application/json',
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(item)
        }

        fetch("https://northwind.vercel.app/api/categories", requestOptions)
        .then((res) => res.json())
        .then((data) => {

            setCategories([...categories, data]);
        })

    }



    return (
        <div>
            <AddCategory addNewCategory={addNewCategory}></AddCategory>
            <CategoryList categories={categories} deleteCategory={deleteCategory}></CategoryList>

        </div>
    )
}

export default CategoryPage
