import React, { useState } from 'react'

function AddCategory(props) {

    const [categoryName, setCategoryName] = useState('');
    const [description, setDescription] = useState('');

    const add = () => {

        let randomId = Math.floor(Math.random() * 1000000);
        
        let newCategory = {
            name:categoryName,
            description: description,
            // id:randomId
        };

        props.addNewCategory(newCategory);

    }

    return (
        <div>
            <div>
                <label>Name:</label>
                <input type='text' value={categoryName} onChange={(e) => setCategoryName(e.target.value) } />
            </div>

            <div>
                <label>Description:</label>
                <input type='text' value={description} onChange={(e) => setDescription(e.target.value) } />
            </div>

            <div>
                <button onClick={() => add()}>Add</button>
            </div>
        </div>
    )
}

export default AddCategory
