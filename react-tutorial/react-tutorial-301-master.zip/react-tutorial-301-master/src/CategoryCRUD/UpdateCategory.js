import React, { useEffect, useState } from 'react'
import { useNavigate, useParams } from 'react-router-dom'

function UpdateCategory() {

    let { id } = useParams();


    const [categoryName, setCategoryName] = useState('');
    const [description, setDescription] = useState('');

    let navigate = useNavigate();

    useEffect(() => {

        fetch("https://northwind.vercel.app/api/categories/" + id)
            .then(res => res.json())
            .then((data) => {
                
                setCategoryName(data.name);
                setDescription(data.description);
            })


    }, []);

    const update = () => {

        //northwind.now.sh/api/categories

        let requestOptions = {
            method: 'PUT',
            headers: {
                'Accept': 'application/json',
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({id:id,name:categoryName,description:description})
        }

        fetch("https://northwind.now.sh/api/categories", requestOptions)
        .then(res => res.json())
        .then((data) => {


            console.log('DATA',data);
            navigate('/kategoriler');

        })

    }

    return (
        <div>
            <h1>Update Category Page</h1>
            <div>
                <label>Name:</label>
                <input type='text' value={categoryName} onChange={(e) => setCategoryName(e.target.value) } />
            </div>

            <div>
                <label>Description:</label>
                <input type='text' value={description} onChange={(e) => setDescription(e.target.value) } />
            </div>

            <div>
                <button onClick={() => update()}>Update</button>
            </div>
        </div>
    )
}

export default UpdateCategory
