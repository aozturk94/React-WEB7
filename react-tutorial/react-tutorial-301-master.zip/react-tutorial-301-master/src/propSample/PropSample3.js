import React from 'react'

function PropSample3(props) {

    return (
        <div>
            <h1>Product Name: {props.product.name}</h1>
            <h1>Unit Price: {props.product.price}</h1>

        </div>
    )
}

export default PropSample3
