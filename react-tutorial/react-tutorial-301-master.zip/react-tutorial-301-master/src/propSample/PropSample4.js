import React from 'react'

function PropSample4(props) {

    return (
        <div>
            <h1>Year: {props.year}</h1>
            <ul>
                {
                    props.cities.map((item) => (<li>{item}</li>))
                }
            </ul>

        </div>
    )
}

export default PropSample4
