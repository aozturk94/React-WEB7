import React from 'react'

function ProductList(props) {

    const { products } = props;


    return (
        <>
            <table>
                <tr>
                    <td>Id</td>
                    <td>Name</td>
                    <td>Unit Price</td>
                </tr>

                {
                    products.map((item, key) => {

                        return <tr>
                            <td>{item.id}</td>
                            <td>{item.name}</td>
                            <td>{item.unitPrice}</td>
                        </tr>

                    })
                }
            </table>
        </>
    )
}

export default ProductList
