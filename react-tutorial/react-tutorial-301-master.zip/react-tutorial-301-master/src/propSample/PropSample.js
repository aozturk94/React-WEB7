import React from 'react'

function PropSample({name, surname}) {

    return (
        <div>
            <h1>User Name: {name}</h1>
            <h1>User Surname: {surname}</h1>
        </div>
    )
}

export default PropSample



