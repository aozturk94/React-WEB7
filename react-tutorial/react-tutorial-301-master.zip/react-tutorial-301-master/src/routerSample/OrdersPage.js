import React, { useState, useEffect } from 'react'
import { Link } from 'react-router-dom';

function OrdersPage() {



    const [orders, setOrders] = useState([]);

    useEffect(() => {

        fetch("https://northwind.vercel.app/api/orders")
            .then(res => res.json())
            .then((data) => {
                setOrders(data);
            })

    }, [])


    return (
        <>
            <table>
                <tr>
                    <td>ID</td>
                    <td>Ship Name</td>
                    <td>Ship Via</td>
                    <td>Customer Id</td>
                    <td>Detail</td>
                </tr>

                {
                    orders && orders.map((item, key) => {
                        return <tr>
                            <td>{item.id}</td>
                            <td>{item.shipName}</td>
                            <td>{item.shipVia}</td>
                            <td>{item.customerId}</td>
                            <td><Link to={'/siparisler/' + item.id}>Detail</Link></td>
                        </tr>
                    })
                }
            </table>
        </>
    )
}

export default OrdersPage
