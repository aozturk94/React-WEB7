import React from 'react'

function NoMatch() {
    return (
        <div>
            <h1>404 Page</h1>
        </div>
    )
}

export default NoMatch
