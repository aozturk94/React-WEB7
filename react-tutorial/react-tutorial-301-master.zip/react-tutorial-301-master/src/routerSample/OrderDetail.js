import React, { useEffect, useState } from 'react'
import { useNavigate, useParams } from 'react-router-dom'


function OrderDetail() {

    let { id } = useParams();
    let navigate = useNavigate();
    

    const [orderDetail, setOrderDetail] = useState({});
    const [loading, setLoading] = useState(true)

    useEffect(() => {
        fetch("https://northwind.vercel.app/api/orders/" + id)
            .then(res => res.json())
            .then((data) => {
                setOrderDetail(data);
                setLoading(false)
            })
    }, [])

    const goHome = () => {
        navigate('/');
    }

    return (
        <div>
            <button onClick={() => goHome()}>Go to Home Page</button>
            {
                loading == true ? <h1>loading...</h1> : <>       <h1>Order Detail Page</h1>
                    <h1>Id: {orderDetail.id} </h1>
                    <h1>Ship Name: {orderDetail.shipName} </h1>
                    <h1>Ship Via: {orderDetail.shipVia} </h1> </>
            }
        </div>
    )
}

export default OrderDetail
