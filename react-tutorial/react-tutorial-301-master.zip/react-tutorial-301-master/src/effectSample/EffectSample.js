import React, { useEffect, useState } from 'react'

function EffectSample() {

    const [products, setProducts] = useState([])


    //Component render olduktan sonra SADECE BİR KERE ÇALIŞIR!
    useEffect(() => {

        fetch("https://northwind.vercel.app/api/products")
            .then((res) => res.json())
            .then((data) => {
                setProducts(data);
            })

    }, [])


    return (
        <div>
            <table>
                <tr>
                    <td>Id</td>
                    <td>Name</td>
                    <td>Unit Price</td>
                </tr>

                {
                    products && products.map((item, key) => {
                        return <tr>
                            <td>{item.id}</td>
                            <td>{item.name}</td>
                            <td>{item.unitPrice}</td>
                        </tr>
                    })
                }
            </table>
        </div>
    )
}

export default EffectSample
