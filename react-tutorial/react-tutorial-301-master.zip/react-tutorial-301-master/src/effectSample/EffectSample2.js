import React, { useEffect, useState } from 'react'

function EffectSample2() {

    const [sayac, setSayac] = useState(0);


    console.log('Function rendered!');

    //Boş dizi işareti varsa useEffect SADECE BİR KEZ ÇALIŞIR
    useEffect(() => {
        console.log('Effect render!');
    }, []);

    useEffect(() => {
        
        console.log('Sayaç state changed!');

    }, [sayac]);

    

    return (
        <div>
            <h1>{sayac}</h1>
            <button onClick={() => setSayac(sayac + 1)}>Arttir</button>
        </div>
    )
}

export default EffectSample2
