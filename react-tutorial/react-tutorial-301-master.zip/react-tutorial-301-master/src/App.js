
import { Routes, Route, Link } from 'react-router-dom'
import Home from './routerSample/Home'
import About from './routerSample/About'
import Contact from './routerSample/Contact'
import OrdersPage from './routerSample/OrdersPage'
import OrderDetail from './routerSample/OrderDetail'
import NoMatch from './routerSample/NoMatch'
import 'antd/dist/antd.css';
import AntDesignSample from './antdSample/AntDesignSample'
import ProductTable from './antdSample/ProductTable'
import AddProduct from './antdSample/AddProduct'
import CategoryPage from './CategoryCRUD/CategoryPage'
import UpdateCategory from './CategoryCRUD/UpdateCategory'

function App() {

  let newProduct = {
    name: 'IPhone',
    price: 5000,
    unitsInStock: 20
  }

    


  let cities = ['İstanbul', 'Ankara', 'İzmir', 'Trabzon'];

  const merhaba = () => {
    alert('Merhaba props!! Ben parenttan bir arkadaşınım!')
  }
  

  
  let navStyle = {display:'flex',justifyContent:'space-evenly'}
  return (
    <>
      <nav style={navStyle}>
        <Link to='/'>Home</Link>
        <Link to='/hakkimizda'>Hakkımızda</Link>
        <Link to='/iletisim'>İletişim</Link>
        <Link to='/siparisler'>Siparişler</Link>
        <Link to='/urunler'>Ürünler</Link>
        <Link to='/urunekle'>Ürün Ekle</Link>
        <Link to='/kategoriler'>Kategoriler</Link>

      </nav>

      <Routes>
        <Route path='/' element={<Home />}></Route>
        <Route path='/hakkimizda' element={<About />}></Route>
        <Route path='/iletisim' element={<Contact />}></Route>
        <Route path='/siparisler' element={<OrdersPage/>}></Route>
        <Route path='/siparisler/:id' element={<OrderDetail/>}></Route>
        <Route path='/antdsample' element={<AntDesignSample/>}></Route>
        <Route path='/urunler' element={<ProductTable/>}></Route>
        <Route path='/urunekle' element={<AddProduct/>}></Route>
        <Route path='/kategoriler' element={<CategoryPage/>}></Route>
        <Route path='/kategoriler/guncelle/:id' element={<UpdateCategory/>}></Route>

        <Route path='*' element={<NoMatch/>}></Route>

      </Routes>


    </>
  )

}

export default App

