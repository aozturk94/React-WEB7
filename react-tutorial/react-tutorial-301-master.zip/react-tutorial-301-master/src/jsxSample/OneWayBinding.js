import React from 'react'

function OneWayBinding() {

    let name = "Çağatay";
    let surname = "Yıldız";
    let year = 2022;

    let metalBand = {
        name : 'Iron Maiden',
        country: 'U.K.'
    }

    return (
        <div>
            <h1>Name:  {metalBand.name}</h1>
            <h1>Name: {name}</h1>
            <h1>Surname: {surname}</h1>
            <h1>Year: {year}</h1>
        </div>
    )
}

export default OneWayBinding
