import React from 'react'
import { Form, Input, Button } from 'antd';


function AddProduct() {


    const onSubmit = (values) => {

        let requestOptions = {
            method: 'POST',
            headers: {
                'Accept': 'application/json',
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(values)
        }

        fetch("https://northwind.vercel.app/api/products", requestOptions)
        .then((res) => res.json())
        .then((data) => {

            console.log('Success');
        })

    }

    return (
        <>
            <Form
                name="basic"
                labelCol={{ span: 8 }}
                wrapperCol={{ span: 16 }}
                onFinish={onSubmit}
            >
                <Form.Item
                    label="Product Name:"
                    name="name"
                    rules={[{ required: true, message: 'Please input your product name!' }]}
                >
                    <Input />
                </Form.Item>

                <Form.Item
                    label="Unit Price:"
                    name="unitPrice"
                    rules={[{ required: true, message: 'Please input your unit price!' }]}
                >
                    <Input />
                </Form.Item>

                <Form.Item wrapperCol={{ offset: 8, span: 16 }}>
                    <Button type="primary" htmlType="submit">
                        Add
                    </Button>
                </Form.Item>

            </Form>
        </>
    )
}

export default AddProduct
