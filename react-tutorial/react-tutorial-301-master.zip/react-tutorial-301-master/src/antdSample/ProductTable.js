import { Table } from 'antd';
import React, { useEffect, useState } from 'react'

function ProductTable() {

    const [products, setProducts] = useState([]);

    useEffect(() => {

        fetch("https://northwind.vercel.app/api/products")
            .then(res => res.json())
            .then((data) => {
                setProducts(data);
            })

    }, []);


    let columns = [
        {
            title:'ID',
            dataIndex:'id',
            key:'id'
        },
        {
            title:'Name',
            dataIndex:'name',
            key:'name'
        },
        {
            title:'Category Id',
            dataIndex:'categoryId',
            key:'categoryId'
        },
        {
            title:'Unit Price',
            dataIndex:'unitPrice',
            key:'unitPrice'
        }
    ]

    return (
        <div>
            <Table dataSource={products} columns={columns} />
        </div>
    )
}

export default ProductTable
