import React from 'react'
import { Button } from 'antd'


function AntDesignSample() {
    return (
        <div>
            <Button type='primary'>Hello Ant Design</Button>
        </div>
    )
}

export default AntDesignSample
